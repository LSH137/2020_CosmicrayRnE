#pragma once

#define Threadnum 10
#define MAX_FILENUM 30000
#define Histogram_nclass 600
#define MaxFluxIn1Hour 100000000
#define SIGMA 1

const char OBSERVED_DATA_DIR[100] = {"/media/cosmicray/CosmicrayRnE/COSMICRAY_DATA/Processed/result/histogram"};
const char SIMULATED_HISTOGRAM_DIR[100] = { "/media/cosmicray/CosmicrayRnE/COSMICRAY_DATA/Processed/result/histogram" };