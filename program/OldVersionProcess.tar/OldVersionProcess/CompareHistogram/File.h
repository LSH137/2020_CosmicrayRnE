#pragma once

int GetFileName(const char search_Path[250], char(*file_name)[250]);

void MakePercent(int start, int end, int threadnum);

void Gather();