#pragma once

void WhoInThere(int start, int end, int threadnum);