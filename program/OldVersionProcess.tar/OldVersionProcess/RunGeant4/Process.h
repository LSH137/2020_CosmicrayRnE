//
// Created by lsh on 20. 3. 4..
//

#ifndef DATAPROCESS_VER6L_PROCESS_H
#define DATAPROCESS_VER6L_PROCESS_H

void SortSimulationData();


#endif //DATAPROCESS_VER6L_PROCESS_H
