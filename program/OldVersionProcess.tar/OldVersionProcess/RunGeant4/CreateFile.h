//
// Created by lsh on 20. 4. 3..
//

#ifndef MAKE_G4PROJECT_CREATEFILE_H
#define MAKE_G4PROJECT_CREATEFILE_H

void MakeFile(int number_of_proj);

#endif //MAKE_G4PROJECT_CREATEFILE_H
