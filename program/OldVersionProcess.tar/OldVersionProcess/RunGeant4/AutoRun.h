//
// Created by lsh on 20. 4. 4..
//

#ifndef DATAPROCESS_VER6L_AUTORUN_H
#define DATAPROCESS_VER6L_AUTORUN_H

void ControlAutoRun(int number_of_proj, int repeat);

#endif //DATAPROCESS_VER6L_AUTORUN_H
