//
// Created by lsh on 20. 4. 3..
//

#ifndef MAKE_G4PROJECT_BUILDG4PROJ_H
#define MAKE_G4PROJECT_BUILDG4PROJ_H

void Build(int number_of_proj);

#endif //MAKE_G4PROJECT_BUILDG4PROJ_H
