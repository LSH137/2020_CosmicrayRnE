//
// Created by lsh on 20. 4. 1..
//

#ifndef DATAPROCESS_VER6L_GATHERING_H
#define DATAPROCESS_VER6L_GATHERING_H

#include "Class.h"



int GatherFlux();

void GatherEdep();

//void ConvertCloudData(int end_year, int end_month, int end_day, int end_hour);

//void ConvertEdep();

//void MixFluxAndCloud(Cloud cloud);

#endif //DATAPROCESS_VER6L_GATHERING_H
