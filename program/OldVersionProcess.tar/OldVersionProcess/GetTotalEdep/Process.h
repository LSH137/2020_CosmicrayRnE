//
// Created by lsh on 20. 3. 4..
//

#ifndef DATAPROCESS_VER6L_PROCESS_H
#define DATAPROCESS_VER6L_PROCESS_H

void ProcessData(int threadnum, int name_index_low, int name_index_high);

int DivideEdepByHour(int hour);

#endif //DATAPROCESS_VER6L_PROCESS_H
