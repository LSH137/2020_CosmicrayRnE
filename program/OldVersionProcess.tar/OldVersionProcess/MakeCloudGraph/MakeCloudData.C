#include "Riostream.h"
#include <stdio.h>
#include <cstdlib>
#include <vector>
#include <algorithm>

#include "Constant.h"

long long int MonthToDay(int year, int month)
{
    switch (month) {
        case 1:
            return 0;
        case 2:
            return 31;
        case 3:
        {
            if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) return MonthToDay(year, 2) + 29;
            else return MonthToDay(year, 2) + 28;
        }
        case 4:
            return 31 + MonthToDay(year, 3);
        case 5:
            return 30 + MonthToDay(year, 4);
        case 6:
            return 31 + MonthToDay(year, 5);
        case 7:
            return 30 + MonthToDay(year, 6);
        case 8:
            return 31 + MonthToDay(year, 7);
        case 9:
            return 31 + MonthToDay(year, 8);
        case 10:
            return 30 + MonthToDay(year, 9);
        case 11:
            return 31 + MonthToDay(year, 10);
        case 12:
            return 30 + MonthToDay(year, 11);
        default:
            return 0;
    }
}

class Flux
{
public:
    Flux()
    {
        year = 0;
        month = 0;
        day = 0;
        hour = 0;
        minute = 0;
        sec = 0;
        flux = 0;
        time = 0;
    }
    ~Flux() = default;



    void ConvertTime() // second past after 2019/1/1 0:0:0
    {
        unsigned long long int daypass;
        daypass = (year-2019) * 365 + MonthToDay(year, month) + day;
        time = daypass * 86400 + hour * 3600 + minute * 60 + sec;
    }

    unsigned long long int time;
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int sec;
    int flux;
};

class Time
{
public:
    Time()
    {
        year = 0;
        month = 0;
        day = 0;
        hour = 0;
        minute = 0;
        sec = 0;
        time = 0;
    }

    ~Time()
    {
        year = 0;
        month = 0;
        day = 0;
        hour = 0;
        minute = 0;
        sec = 0;
        time = 0;
    }

    void ConvertTime() // second past after 2019/1/1/0/0
    {
        unsigned long long int daypass;
        daypass = (year - 2019) * 365 + MonthToDay(year, month) + day;

        time = daypass * 86400 + hour * 3600 + minute * 60 + sec;
    }

    int year;
    int month;
    int day;
    int hour;
    int minute;
    int sec;
    unsigned long long int time;
};

struct CloudData
{
    Time time;
    int totc = 0;
    int fog = 0;
    int lowc = 0;
    int midc = 0;
    int highc = 0;
};

bool cmp(CloudData d1, CloudData d2)
{
    return d1.time.time < d2.time.time;
}

bool cmp2(Flux d1, Flux d2)
{
    return d1.time < d2.time;
}


//CloudData cloud_data;
//Flux flux;


void MakeCloudData()
{
    Flux* flux = new Flux[8000000];
    CloudData* cloud_data = new CloudData[3500];
    FILE* fp_cloud;
    FILE* fp_flux;
    auto mg = new TMultiGraph();
    auto C = new TCanvas("observed_data","observed_data",1200, 600);

    TGraph *gflux = new TGraph();
    TGraph *gcloud_fog = new TGraph();
    TGraph *gcloud_totc = new TGraph();
    TGraph *gcloud_highc = new TGraph();
    TGraph *gcloud_midc = new TGraph();
    TGraph *gcloud_low = new TGraph();

    fp_cloud = fopen64("cloudData.csv", "r");
    fp_flux = fopen64("flux.txt", "r");

    if(fp_cloud != nullptr && fp_flux != nullptr)
    {
        int index = 0;
        while(!feof(fp_cloud))
        {
            fscanf(fp_cloud, "%d. %d. %d,%d:%d,%d,%d,%d,%d,%d", &cloud_data[index].time.year, &cloud_data[index].time.month, &cloud_data[index].time.day, &cloud_data[index].time.hour, &cloud_data[index].time.minute, &cloud_data[index].totc, &cloud_data[index].fog, &cloud_data[index].lowc, &cloud_data[index].midc, &cloud_data[index].highc);
            
            printf("time: %lld %d %d %d %d\n", cloud_data[index].time.year, cloud_data[index].time.month, cloud_data[index].time.day, cloud_data[index].time.hour, cloud_data[index].time.minute);
            cloud_data[index].time.ConvertTime();

            index++;
        }

        printf("index: %d sort cloud\n", index);

        std::sort(cloud_data, cloud_data+index, cmp);
        printf("sort end\n");

        for(int i = 0; i < index; i = i + 3)
        {
             if(cloud_data[i].time.time > 30000000 && cloud_data[i].time.time < 34000000)
             {
                gcloud_totc->SetPoint(gcloud_totc->GetN(), cloud_data[i].time.time, cloud_data[i].totc);
                gcloud_highc->SetPoint(gcloud_highc->GetN(), cloud_data[i].time.time, cloud_data[i].highc);
                gcloud_midc->SetPoint(gcloud_midc->GetN(), cloud_data[i].time.time, cloud_data[i].midc);
                gcloud_low->SetPoint(gcloud_low->GetN(), cloud_data[i].time.time, cloud_data[i].lowc);
                gcloud_fog->SetPoint(gcloud_fog->GetN(), cloud_data[i].time.time, cloud_data[i].fog);
             }
            
        }

        printf("flux data\n");
        index = 0;
        while(!feof(fp_flux) && index < 8000000)
        {
            fscanf(fp_flux, "%lld %d %d %d %d %d %d %d", &flux[index].time, &flux[index].year, &flux[index].month, &flux[index].day, &flux[index].hour, &flux[index].minute, &flux[index].sec, &flux[index].flux);
            index++;
        }

        printf("index: %d sort flux\n", index);

        std::sort(flux, flux+index, cmp2);
        printf("sort end\n");

        for(int i = 0; i < index; i = i++)
        {
            if(flux[i].time > 30000000 && flux[i].time < 34000000 && flux[i].flux*10 < 200)
                gflux->SetPoint(gflux->GetN(), flux[i].time, flux[i].flux * 10);
        }
            


        gflux->SetTitle("flux");
        gcloud_low->SetTitle("low cloud");
        gcloud_midc->SetTitle("middle cloud");
        gcloud_highc->SetTitle("high cloud");
        gcloud_totc->SetTitle("total cloud");
        gcloud_fog->SetTitle("fog");

        C->cd();
        mg->Add(gflux, "PL");
        mg->Add(gcloud_low, "PL");
        mg->Add(gcloud_fog, "PL");
        mg->Add(gcloud_totc, "PL");
        mg->Add(gcloud_midc, "PL");
        mg->Add(gcloud_highc, "PL");
        mg->Draw("A pmc plc");

        C->BuildLegend();
        C->SaveAs("cloud-flux.png");

        fclose(fp_cloud);
        fclose(fp_flux);
    }

    delete[] cloud_data;
    delete[] flux;
}